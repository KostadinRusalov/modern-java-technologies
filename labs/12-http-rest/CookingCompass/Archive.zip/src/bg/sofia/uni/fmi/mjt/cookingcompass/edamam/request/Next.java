package bg.sofia.uni.fmi.mjt.cookingcompass.edamam.request;

public record Next(String href) {
}
