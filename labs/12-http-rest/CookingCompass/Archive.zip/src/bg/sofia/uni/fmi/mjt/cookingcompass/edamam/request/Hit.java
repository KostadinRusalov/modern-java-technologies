package bg.sofia.uni.fmi.mjt.cookingcompass.edamam.request;

import bg.sofia.uni.fmi.mjt.cookingcompass.Recipe;

public record Hit(Recipe recipe) {
}
